KangoAPI.onReady(function() {
    $('#close').click(function(event) {
        KangoAPI.closeWindow()
    });

 	$('#container').hover(function(e) {
    	$('#logo').toggleClass('logoRed');
	})

	$( "#close" )
  		.on( "mouseenter", function() {
	    $("#message").text('close window').stop().fadeIn(600);
	  })
	  .on( "mouseleave", function() {
	    $("#message").stop().fadeOut(600)
	  });
    var option1 = kango.storage.getItem('option1');
    var option2 = kango.storage.getItem('option2');
    var option3 = kango.storage.getItem('option3');
    var option4 = kango.storage.getItem('option4');
    var option5 = kango.storage.getItem('option5');

    if((option1 === 0) || (option1 === null)){
    	$('#option1').prop('checked', true);
    }else{
    	$('#option1').prop('checked', false);
    }

    if((option2 === 0) || (option2 === null)){
    	$('#option2').prop('checked', true);
    }else{
    	$('#option2').prop('checked', false);
    }

    if((option3 === 0) || (option3 === null)){
    	$('#option3').prop('checked', true);
    }else{
    	$('#option3').prop('checked', false);
    }

    if((option4 === 0) || (option4 === null)){
    	$('#option4').prop('checked', true);
    }else{
    	$('#option4').prop('checked', false);
    }

    if((option5 === 0) || (option5 === null)){
    	$('#option5').prop('checked', true);
    }else{
    	$('#option5').prop('checked', false);
    }

    $('#option1').click(function(){
    	if(kango.storage.getItem('option1') == 1){
    		kango.storage.setItem('option1',0);
    	}else{
    		kango.storage.setItem('option1',1);
    	}
    });

    $('#option2').click(function(){
    	if(kango.storage.getItem('option2') == 1){
    		kango.storage.setItem('option2',0);
    	}else{
    		kango.storage.setItem('option2',1);
    	}
    });

    $('#option3').click(function(){
    	if(kango.storage.getItem('option3') == 1){
    		kango.storage.setItem('option3',0);
    	}else{
    		kango.storage.setItem('option3',1);
    	}
    });

    $('#option4').click(function(){
    	if(kango.storage.getItem('option4') == 1){
    		kango.storage.setItem('option4',0);
            $("#message").text('herlaad ants om wijziging toe te passen').stop().fadeIn(300).delay(2000).fadeOut(600);
    	}else{
    		kango.storage.setItem('option4',1);
            $("#message").text('herlaad ants om wijziging toe te passen').stop().fadeIn(300).delay(2000).fadeOut(600);
    	}
    });

    $('#option5').click(function(){
    	if(kango.storage.getItem('option5') == 1){
    		kango.storage.setItem('option5',0);
			$("#message").text('herlaad ants om wijziging toe te passen').fadeIn(300).delay(2000).fadeOut(600);

    	}else{
    		kango.storage.setItem('option5',1);
    		$("#message").text('herlaad ants om wijziging toe te passen').fadeIn(300).delay(2000).fadeOut(600);
    		
    	}
    });

});