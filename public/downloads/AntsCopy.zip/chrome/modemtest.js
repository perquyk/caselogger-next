// ==UserScript==
// @Modemtest
// @include http://ants.inet.telenet.be/tools/modems/modemtest*
// @require jquery-1.11.2.js
// @require jquery-ui.js
// @require highcharts.js
// @require clipboard2.js




// ==/UserScript==



function SelectText(element) {
    var doc = document
        , text = doc.getElementById(element)
        , range, selection
    ;    
    if (doc.body.createTextRange) {
        range = document.body.createTextRange();
        range.moveToElementText(text);
        range.select();
    } else if (window.getSelection) {
        selection = window.getSelection();        
        range = document.createRange();
        range.selectNodeContents(text);
        selection.removeAllRanges();
        selection.addRange(range);
    }   
    console.log("cross loaded: select functie");
}

function kleurwaarde(value , type){
    switch(type)
    {
        case 'schommel':

            var style ="";
            if (value >= 6){
                style = 'class="text-state-error"';
            }else{
                style = 'class="text-state-success"';
            }
            return style;

        case 'ds-SNR freq':

            if (value >= 34){
            style = 'class="text-state-success"';        
            }else{
                if (value < 30){
                    style = 'class="text-state-error"';
                }else{
                    style ='class="text-state-warning"';
                }        
            }
            return style;

        case 'RX freq':
            
            var style ="";
            if ((value <= 15) && (value >= -13)){
                
                if(value < -4){
                    style ='class="text-state-warning"';
                    
                    
                }else{
                    style = 'class="text-state-success"';
                }
            }else{
                style = 'class="text-state-error"';
                
            }
            return style;

        case 'TX freq':

            var style ="";
            if ((value <= 52) && (value >= 26)){
                if((value <= 47) && (value >= 28)){
                    style = 'class="text-state-success"';
                }else{
                    style ='class="text-state-warning"';
                    
                }
                
            }else{
                style = 'class="text-state-error"';
                
            }
            return style;

        default: 
            return "";

    }
}




$('head').append('<style>h1:hover {cursor:pointer;}</style>');
//$('.scroll-up').after('<script type="text/javascript" src="https://www.gstatic.com/charts/44/js/jsapi_compiled_format_module.js"></script><script type="text/javascript" src="https://www.gstatic.com/charts/44/js/jsapi_compiled_default_module.js"></script><script type="text/javascript" src="https://www.gstatic.com/charts/44/js/jsapi_compiled_ui_module.js"></script><script type="text/javascript" src="https://www.gstatic.com/charts/44/js/jsapi_compiled_corechart_module.js"></script><script type="text/javascript" src="https://www.gstatic.com/charts/44/js/jsapi_compiled_controls_module.js"></script>');



//google.charts.load('current', {'packages':['corechart', 'controls']});
console.log('chartsjs added');


if(kango.storage.getItem('option4') !== 1){

    
   
}      


//versie 1.3
$("body").on( "click", "a[href$='tab-levels']", function(){
    if(kango.storage.getItem('option4') !== 1){

        if ($('#grafiekBut').length){

            //doe niets als grafiekbut div aanwezig is

        }else{


        }

                 
    }

    //sammenvatting toevoegen
    if ($('#samenvatting').length){

    }else{

        $('#tab-levels .data-table').attr('id', 'data-table');
        
        //update 2.5


        var countTD = $("#data-table tr:eq(2)").children('td').length;
        var trReversed = $($('#data-table tbody tr').get().reverse());
        var LoopA = trReversed.length;
        var trHead = $('#data-table thead tr:eq(0) th');
        var trType = $('#data-table thead tr:eq(1)').children();

        arRX = {};
        arTX = {};
        arRXSNR = {};
        arTXSNR = {};

        for (i = 1; i < countTD; i++) {

            //var for knowing first td
            countDate = i - 1;

            //freq count
            if (i > 1) {
                countFreq = Math.ceil(i / 2);
            } else {
                countFreq = i;
            }

            //Store the value of the last cell we visited:
            var lastValue = null;

            //looping true each cell vertically backwards, from bottom to top
            for (var a = 0, l = LoopA; a < l; a++) {

                var tdIndex = $(trReversed[a]).children();

                tdCount = tdIndex[i];

                freq = trHead[countFreq].innerHTML;

                value = tdCount.innerHTML;

                date = tdIndex[0].innerHTML;

                type = trType[i].innerHTML;
                //If we do not have a valid value but lastValue is valid, set valid to lastValue so we can use the value from a previous cell of the same type.
                if (!value && lastValue) {
                    value = lastValue;
                }
                //Otherwise, value must be valid, so set lastValue to value.
                else {
                    lastValue = value;
                }
                //filling the arrays based on type
                if (value !== "") {
                    if (type == "RX") {

                        snrtype = type;

                        if (freq in arRX) {

                            arRX[freq].push({
                                "value": "" + value + "",
                                    "date": "" + date + ""
                            });

                        } else {

                            arRX[freq] = [{
                                "value": "" + value + "",
                                    "date": "" + date + ""
                            }];

                        }

                    } else if (type == "TX") {

                        snrtype = type;

                        if (freq in arTX) {

                            arTX[freq].push({
                                "value": "" + value + "",
                                    "date": "" + date + ""
                            });

                        } else {

                            arTX[freq] = [{
                                "value": "" + value + "",
                                    "date": "" + date + ""
                            }];

                        }
                    //nothing found so it is a snr    
                    } else {

                        if (snrtype == "RX") {

                            if (freq in arRXSNR) {

                                arRXSNR[freq].push({
                                    "value": "" + value + "",
                                        "date": "" + date + ""
                                });

                            } else {

                                arRXSNR[freq] = [{
                                    "value": "" + value + "",
                                        "date": "" + date + ""
                                }];

                            }

                        } else if (snrtype == "TX") {

                            if (freq in arTXSNR) {

                                arTXSNR[freq].push({
                                    "value": "" + value + "",
                                        "date": "" + date + ""
                                });

                            } else {
                                arTXSNR[freq] = [{
                                    "value": "" + value + "",
                                        "date": "" + date + ""
                                }];

                            }
                        }
                    }
                }
            }
        }

        console.log(arTX);
        function createTable(array, title) {
            var table = ""
            table += "<table class='data-table' style='text-align:center; width:300px;'><thead><tr><th>"+title+"</th><th>&nbsp;&nbsp;&nbsp;&nbsp;min</th><th>&nbsp;&nbsp;&nbsp;&nbsp;max</th><th>&nbsp;&nbsp;&nbsp;&nbsp;delta</th></tr></thead><tbody>";
            for (property in array) {
                min = Math.min.apply(Math, array[property].map(function (o) {
                    return o.value;
                }));
                max = Math.max.apply(Math, array[property].map(function (o) {
                    return o.value;
                }));
                schommel = parseFloat((max - min).toFixed(1));
                table += "<tr><td>" + property + "</td>" +
                    "<td "+kleurwaarde(min, title)+" >" + min + "</td>" +
                    "<td "+kleurwaarde(max, title)+" >" + max + "</td>";
                if(title !== "us-SNR freq"){
                    table += "<td "+kleurwaarde(schommel,"schommel")+ ">" + schommel + "</td></tr>";
                }else{
                    table +="<td>" + schommel + "</td></tr>";
                }
                    

            }
            table += "</tbody></table><br>";
            return table;
        }

        twoColumn =    "<div id='samenvatting' style='margin-left:300px;'>"+
                            "<div id='grafiekContent' style='float: right; width: 100%; '></div>"+
                            "<div id='samen' style='float: left; width: 300px; margin-left:-300px;'></div>"+
                            "<div style='clear: both;'></div>"
                        "</div>";
        $('#tab-levels').prepend(twoColumn);
        $('#samen').append(createTable(arTX, "\xa0\xa0\xa0TX-freq"));
        $('#samen').append(createTable(arRX, "\xa0\xa0\xa0RX-freq"));
        $('#samen').append(createTable(arRXSNR, "\xa0\xa0\xa0DS-SNR freq"));
        //('#samen').append(createTable(arTXSNR, "us-SNR freq"));
        
        //$('#samenvatting').append($("#tab-levels .data-table"));
        $('#samen').prepend('<a href="#grafiek" id="grafiekBut"></a>'); 


        //$('#tab-levels').append('<div id="clearme" style="clear:both;"></div>');
        if(kango.storage.getItem('option5') !== 1){

            var clickEvent  = document.createEvent ("HTMLEvents");
            clickEvent.initEvent ("click", true, true);

            $("#grafiekBut")[0].dispatchEvent (clickEvent);
            
        }

    }
});

$("body").on( "click", "#grafiekBut", function(){

    if ($('#grafiekResult').length){
  
        console.log("geen grafieken geladen, grafieken waren al geladen");

    }else{
    
        $('#grafiekContent').append('<div id="grafiekResult" style="margin-left:30px;" ><div id="chartTX" style="min-width: 310px; margin: 0 auto"></div><div id="chartRX" style="min-width: 310px; margin: 0 auto"></div><div id="chartRXSNR" style="min-width: 310px; margin: 0 auto"></div><div id="chartTXSNR" style="min-width: 310px; margin: 0 auto"></div>');
        
        
        dataSerie = [];
        dataTest = [];
               
                var MyDate = new Date();
                lastI = "";
                lastTime =0;
               
               Object.keys(arTX).forEach(function(k) {
                    
                    

                  arTX[k].forEach(function(entry) {       
                    // Split timestamp into [ Y, M, D, h, m, s ]
                    var t = entry['date'].split(/[- :]/);

                    // Apply each element to the Date function      
                    var ab = Date.UTC(+t[0], t[1]-1, +t[2], +t[3], +t[4], +t[5]);
                    
                    i = parseFloat(entry['value']);
                    
                    if(lastI !== "" && (ab-lastTime)>300000){
                        dataTest.push([ab-120000, lastI]);
                      }
                    
                    
                    dataTest.push([ab, i]);
                    lastI = i;
                    lastTime = ab;
                    
                  });
                  
                  
                  lastValue = dataTest.slice(-1)[0] ;
                  

                  dateFill = Date.UTC(MyDate.getFullYear(), MyDate.getMonth(), MyDate.getDate(), MyDate.getHours(), MyDate.getMinutes()+1, 00);
                  dataTest.push([dateFill,lastValue[1]]);
                  testDate = new Date().getTime();
                  newname = k.replace('Mhz',"");
                  dataSerie.push({
                        name: newname,
                        data: dataTest
                    });  
                  dataTest =[];
                  
                  
                
                    
               });
               
               
               
                        
                        var graphSecondDate = Date.UTC(MyDate.getFullYear(), MyDate.getMonth(), MyDate.getDate(), MyDate.getHours(), MyDate.getMinutes()+1, 00);
                        
                        
                        
                   
                    MyDate.setDate(MyDate.getDate() - 6);
                    var graphFirstDate = Date.UTC(MyDate.getFullYear(), MyDate.getMonth(), ( MyDate.getDate())); 
                        
               
               
                $('#chartTX').highcharts({
                    chart: {
                        type: 'line',
                        backgroundColor: '#f6f6f6',
                        plotBackgroundColor: 'white',
                        
                        
                    },
                    credits: {
                        enabled: false
                    },
                    
                    title: {
                        text: 'US'
                    },
                    
                    legend: {
                        layout: 'vertical',
                        align: 'right',
                        verticalAlign: 'top',
                        floating: false,
                        y: 30,
                        
                    },
                    
                    xAxis: {
                        type: 'datetime',
                        
                        title: {
                            text: 'Datum'
                        },
                        
                            min: graphFirstDate,
                            max: graphSecondDate
                    },
                    yAxis: {
                        title: {
                            text: 'dBmV'
                        },
                        min: 20,
                        max: 60,
                        tickInterval: 10,
                        plotLines: [{
                                value: 25,
                                color: 'red',
                                dashStyle: 'shortdash',
                                width: 1,
                                
                                
                            }, {
                                value: 55,
                                color: 'red',
                                dashStyle: 'shortdash',
                                width: 1,
                                
                            }]
                    },
                    tooltip: {
                            crosshairs: [true, false],
                        useHTML: true,
                        headerFormat: '<span style="text-align: center; font-size:10px;">{point.x:%e %b %H:%M:%S}</span><table>',
                        pointFormat: '<tr><td style="font-size:10px;">{series.name}: </td>' +
                            '<td style="color: {series.color};text-align: right; font-size: 16px;"><b>{point.y:.1f} </b></td></tr>',
                        footerFormat: '</table>',
                        
                    },

                    plotOptions: {
                        spline: {
                            marker: {
                                enabled: false
                            }
                        },
                        series: {
                            lineWidth: 2,
                            states: {
                                hover: {
                                    enabled: true,
                                    lineWidth: 2
                                }
                            }
                        }
                    },

                    series: dataSerie
                });


                //rx

                dataSerie = [];
                dataTest = [];
               
                MyDate = new Date();
                lastI = "";
                lastTime =0;
               
               Object.keys(arRXSNR).forEach(function(k) {
                    
                    

                  arRXSNR[k].forEach(function(entry) {       
                    // Split timestamp into [ Y, M, D, h, m, s ]
                    var t = entry['date'].split(/[- :]/);

                    // Apply each element to the Date function      
                    var ab = Date.UTC(+t[0], t[1]-1, +t[2], +t[3], +t[4], +t[5]);
                    
                    i = parseFloat(entry['value']);
                    
                    if(lastI !== "" && (ab-lastTime)>300000){
                        dataTest.push([ab-120000, lastI]);
                      }
                    
                    
                    dataTest.push([ab, i]);
                    lastI = i;
                    lastTime = ab;
                    
                  });
                  
                  
                  lastValue = dataTest.slice(-1)[0] ;
                  

                  dateFill = Date.UTC(MyDate.getFullYear(), MyDate.getMonth(), MyDate.getDate(), MyDate.getHours(), MyDate.getMinutes()+1, 00);
                  dataTest.push([dateFill,lastValue[1]]);
                  testDate = new Date().getTime();
                  
                  dataSerie.push({
                        name: k,
                        data: dataTest
                    });  
                  dataTest =[];
                  
                  
                
                    
               });
               
               
               
                        
                        var graphSecondDate = Date.UTC(MyDate.getFullYear(), MyDate.getMonth(), MyDate.getDate(), MyDate.getHours(), MyDate.getMinutes()+1, 00);
                        
                        
                        
                   
                    MyDate.setDate(MyDate.getDate() - 6);
                    var graphFirstDate = Date.UTC(MyDate.getFullYear(), MyDate.getMonth(), ( MyDate.getDate())); 
                        
               
               
                $('#chartRXSNR').highcharts({
                    chart: {

                        type: 'line',
                        backgroundColor: '#f6f6f6',
                        plotBackgroundColor: 'white',
                        
                        
                    },
                    credits: {
                        enabled: false
                    },
                    
                    title: {
                        text: 'DS-SNR'
                    },
                    
                    legend: {
                        layout: 'vertical',
                        align: 'right',
                        verticalAlign: 'top',
                        floating: false,
                        y: 30,
                        
                    },
                    
                    xAxis: {
                        type: 'datetime',
                        
                        title: {
                            text: 'Datum'
                        },
                        
                            min: graphFirstDate,
                            max: graphSecondDate
                    },
                    yAxis: {
                        title: {
                            text: 'dBmV'
                        },
                        min: 30,
                        max: 41,
                        tickInterval: 3,
                        plotLines: [{
                                value: 32,
                                color: 'red',
                                dashStyle: 'shortdash',
                                width: 1,
                                
                                
                            }]
                    },
                    tooltip: {
                            crosshairs: [true, false],
                        useHTML: true,
                        headerFormat: '<span style="text-align: center; font-size:10px;">{point.x:%e %b %H:%M:%S}</span><table>',
                        pointFormat: '<tr><td style="font-size:10px;">{series.name}: </td>' +
                            '<td style="color: {series.color};text-align: right; font-size: 16px;"><b>{point.y:.1f} </b></td></tr>',
                        footerFormat: '</table>',
                        
                    },

                    plotOptions: {
                        spline: {
                            marker: {
                                enabled: false
                            }
                        },
                        series: {
                            lineWidth: 2,
                            animation: false
                        }
                    },

                    series: dataSerie
                });


                dataSerie = [];
                dataTest = [];
               
                MyDate = new Date();
                lastI = "";
                lastTime =0;
               
               Object.keys(arRX).forEach(function(k) {
                    
                    

                  arRX[k].forEach(function(entry) {       
                    // Split timestamp into [ Y, M, D, h, m, s ]
                    var t = entry['date'].split(/[- :]/);

                    // Apply each element to the Date function      
                    var ab = Date.UTC(+t[0], t[1]-1, +t[2], +t[3], +t[4], +t[5]);
                    
                    i = parseFloat(entry['value']);
                    
                    if(lastI !== "" && (ab-lastTime)>300000){
                        dataTest.push([ab-120000, lastI]);
                      }
                    
                    
                    dataTest.push([ab, i]);
                    lastI = i;
                    lastTime = ab;
                    
                  });
                  
                  
                  lastValue = dataTest.slice(-1)[0] ;
                  

                  dateFill = Date.UTC(MyDate.getFullYear(), MyDate.getMonth(), MyDate.getDate(), MyDate.getHours(), MyDate.getMinutes()+1, 00);
                  dataTest.push([dateFill,lastValue[1]]);
                  testDate = new Date().getTime();
                  
                  dataSerie.push({
                        name: k,
                        data: dataTest
                    });  
                  dataTest =[];
                  
                  
                
                    
               });
               
               
               
                        
                        var graphSecondDate = Date.UTC(MyDate.getFullYear(), MyDate.getMonth(), MyDate.getDate(), MyDate.getHours(), MyDate.getMinutes()+1, 00);
                        
                        
                        
                   
                    MyDate.setDate(MyDate.getDate() - 6);
                    var graphFirstDate = Date.UTC(MyDate.getFullYear(), MyDate.getMonth(), ( MyDate.getDate())); 
                        
               
               
                $('#chartRX').highcharts({
                    chart: {

                        type: 'line',
                        backgroundColor: '#f6f6f6',
                        plotBackgroundColor: 'white',
                        
                        
                    },
                    credits: {
                        enabled: false
                    },
                    
                    title: {
                        text: 'DS RX'
                    },
                    
                    legend: {
                        layout: 'vertical',
                        align: 'right',
                        verticalAlign: 'top',
                        floating: false,
                        y: 30,
                        
                    },
                    
                    xAxis: {
                        type: 'datetime',
                        
                        title: {
                            text: 'Datum'
                        },
                        
                            min: graphFirstDate,
                            max: graphSecondDate
                    },
                    yAxis: {
                        title: {
                            text: 'dBmV'
                        },
                        min: -20,
                        max: 20,
                        tickInterval: 10,
                        plotLines: [{
                                value: -15,
                                color: 'red',
                                dashStyle: 'shortdash',
                                width: 1,
                                
                                
                            }, {
                                value: 15,
                                color: 'red',
                                dashStyle: 'shortdash',
                                width: 1,
                                
                            }]
                    },
                    tooltip: {
                            crosshairs: [true, false],
                        useHTML: true,
                        headerFormat: '<span style="text-align: center; font-size:10px;">{point.x:%e %b %H:%M:%S}</span><table>',
                        pointFormat: '<tr><td style="font-size:10px;">{series.name}: </td>' +
                            '<td style="color: {series.color};text-align: right; font-size: 16px;"><b>{point.y:.1f} </b></td></tr>',
                        footerFormat: '</table>',
                        
                    },

                    plotOptions: {
                        spline: {
                            marker: {
                                enabled: false
                            }
                        },
                        series: {
                            lineWidth: 2,
                            animation: false
                        }
                    },

                    series: dataSerie
                });
                
                dataSerie = [];
                dataTest = [];
               
                MyDate = new Date();
                lastI = "";
                lastTime =0;
               
               Object.keys(arTXSNR).forEach(function(k) {
                    
                    

                  arTXSNR[k].forEach(function(entry) {       
                    // Split timestamp into [ Y, M, D, h, m, s ]
                    var t = entry['date'].split(/[- :]/);

                    // Apply each element to the Date function      
                    var ab = Date.UTC(+t[0], t[1]-1, +t[2], +t[3], +t[4], +t[5]);
                    
                    i = parseFloat(entry['value']);
                    
                    if(lastI !== "" && (ab-lastTime)>300000){
                        dataTest.push([ab-120000, lastI]);
                      }
                    
                    
                    dataTest.push([ab, i]);
                    lastI = i;
                    lastTime = ab;
                    
                  });
                  
                  
                  lastValue = dataTest.slice(-1)[0] ;
                  

                  dateFill = Date.UTC(MyDate.getFullYear(), MyDate.getMonth(), MyDate.getDate(), MyDate.getHours(), MyDate.getMinutes()+1, 00);
                  dataTest.push([dateFill,lastValue[1]]);
                  testDate = new Date().getTime();
                  
                  dataSerie.push({
                        name: k,
                        data: dataTest
                    });  
                  dataTest =[];
                  
                  
                
                    
               });
               
               
               
                        
                        var graphSecondDate = Date.UTC(MyDate.getFullYear(), MyDate.getMonth(), MyDate.getDate(), MyDate.getHours(), MyDate.getMinutes()+1, 00);
                        
                        
                        
                   
                    MyDate.setDate(MyDate.getDate() - 6);
                    var graphFirstDate = Date.UTC(MyDate.getFullYear(), MyDate.getMonth(), ( MyDate.getDate())); 
                        
               
               
                $('#chartTXSNR').highcharts({
                    chart: {

                        type: 'line',
                        backgroundColor: '#f6f6f6',
                        plotBackgroundColor: 'white',
                        
                        
                    },
                    credits: {
                        enabled: false
                    },
                    
                    title: {
                        text: 'US-SNR'
                    },
                    
                    legend: {
                        layout: 'vertical',
                        align: 'right',
                        verticalAlign: 'top',
                        floating: false,
                        y: 30,
                        
                    },
                    
                    xAxis: {
                        type: 'datetime',
                        
                        title: {
                            text: 'Datum'
                        },
                        
                            min: graphFirstDate,
                            max: graphSecondDate
                    },
                    yAxis: {
                        title: {
                            text: 'dBmV'
                        },
                        min: 20,
                        max: 42,
                        tickInterval: 4,
                        
                    },
                    tooltip: {
                            crosshairs: [true, false],
                        useHTML: true,
                        headerFormat: '<span style="text-align: center; font-size:10px;">{point.x:%e %b %H:%M:%S}</span><table>',
                        pointFormat: '<tr><td style="font-size:10px;">{series.name}: </td>' +
                            '<td style="color: {series.color};text-align: right; font-size: 16px;"><b>{point.y:.1f} </b></td></tr>',
                        footerFormat: '</table>',
                        
                    },

                    plotOptions: {
                        spline: {
                            marker: {
                                enabled: false
                            }
                        },
                        series: {
                            lineWidth: 2,
                            animation: false
                        }
                    },

                    series: dataSerie
                });


    }   

});







 //straat nakijken
    if(kango.storage.getItem('option2') !== 1){
        if(kango.storage.getItem("straat") !== null){
            $("h1").text(kango.storage.getItem("straat"));
            kango.storage.removeItem('straat');
        }
    }

//declaring vars: tableRow(filter) texty(output text) spacing(totaal aantal spaties voor output) total (output for spaties na som)
var tableRow;
var texty = "";
var spacing = 6;
var total = 0;
var joeyTX = [];

//events en logs laden wanneer er op deregs tab word geklikt
$("body").on( "click", "a[href$='tab-deregs']", function(){
    if(kango.storage.getItem('option3') !== 1){ 
    if ($('#result2').length){

        //doe niets als result div aanwezig is

    }else{

        var eventMac = 
        $("#tab-cm th").filter(function() {
            return $(this).text() == "MAC-address";
        }).closest('th').siblings().eq(0).text().replace(/\:/g, '%3A');
		console.log('eventmac:' + eventMac);
        $('#tab-deregs').append('<did id="result2"></div>');
        
        $("#result2").load("http://ants.inet.telenet.be/tools/modems/eventlog.php?host="+eventMac);
    
    }
    }
});


    

if(kango.storage.getItem('option1') !== 1){ 

    var copyText = new Clipboard("h1", {
        text: function(trigger) {

            texty = "";
            //mac,model,versie
            var mac = 
            $("#tab-cm th").filter(function() {
                    return $(this).text() == "MAC-address";
            }).closest('th').siblings().eq(0).text();
    
            var model = 
            $("#tab-cm th").filter(function() {
                return $(this).text() == "Model";
            }).closest('th').siblings().eq(0).text();

            var node = 
            $("#tab-status th").filter(function() {
            return $(this).text() == "Node (Ninas)";
            }).closest('th').siblings().eq(0).text();

            var router = 
            $("#tab-cmts th").filter(function() {
            return $(this).text() == "Name";
            }).closest('th').siblings().eq(0).text();

            var software = 
            $("#tab-cm th").filter(function() {
            return $(this).text() == "Software";
            }).closest('th').siblings().eq(0).text();

            var ipadres = 
            $("#tab-cm th").filter(function() {
            return $(this).text() == "IPv4-address";
            }).closest('th').siblings().eq(0).text();

			var ipadresPublic = 
            $("#tab-hgw th").filter(function() {
            return $(this).text() == "WAN IPv4-address";
            }).closest('th').siblings().eq(0).text();

			var ipadresPublicV6 = 
            $("#tab-hgw th").filter(function() {
            return $(this).text() == "WAN IPv6-address";
            }).closest('th').siblings().eq(0).text();

            var powerup = 
            $("#tab-status th").filter(function() {
            return $(this).text() == "Power-up time";
            }).closest('th').siblings().eq(0).text();

            var registratie = 
            $("#tab-status th").filter(function() {
            return $(this).text() == "Registration time";
            }).closest('th').siblings().eq(0).text();
			
			var lastReboot = 
            $("#tab-status th").filter(function() {
            return $(this).text() == "Last reboot reason";
            }).closest('th').siblings().eq(0).text();

			texty = "Information\n===========\n"
            texty   += "Mac-address:\xa0" + mac +" ("+model+")\n"
            + "Node:\xa0"+ node+ "\n"
            + "CMTS:\xa0"+ router +"\n"
            + "Software:\xa0"+ software +"\n"
            + "WAN IPv4(private):\xa0"+ ipadres + "\n" 
            + "WAN IPv4(public):\xa0"+ ipadresPublic + "\n" 
            + "WAN IPv6(public):\xa0"+ ipadresPublicV6 + "\n" 
            + "Power:\xa0"+ powerup + "\n"
            + "Regis:\xa0"+registratie+"\n"       
            + "Last reboot reason:\xa0"+lastReboot+"\n\n"       
    
            // Downstream
			
			texty += "Downstream\n==========\n";
            texty += "Freq:\xa0";
    
            tableRow = $("#tab-ds th").filter(function() {
             return $(this).text() == "Frequency (MHz)";
            }).closest('tr');
    
            $(tableRow).find('td').each (function() {
               

             var choptext = $(this).text();
                var count = choptext.length;
                total = spacing - count -1;
                texty += choptext;  
                for (i=0; i < total; i++){
                 texty += "\xa0";
                }    
            });
    
			
            texty += "\nRX:\xa0\xa0\xa0";
    
            tableRow = $("#tab-ds th").filter(function() {
                return $(this).text() == "Rx Power (dBmV)";
            }).closest('tr');
    
            $(tableRow).find('td').each (function() {

            //joeyTx

            var count = $(this).text().length;
            total = spacing - count -1;
            texty += $(this).text();  
            for (i=0; i < total; i++){
                    texty += "\xa0";
                }    
            }); 
			
            texty += "\nSNR:\xa0\xa0";
    
            tableRow = $("#tab-ds th").filter(function() {
                return $(this).text() == "SNR";
            }).closest('tr');
    
            $(tableRow).find('td').each (function() {

                var count = $(this).text().length;
                total = spacing - count -1;
                texty += $(this).text();  
                for (i=0; i < total; i++){
                    texty += "\xa0";
                }    
            }); 
			
			// OFDM
			texty += "\n\nOFDM:";
			texty += "\nFreq:\xa0\xa0";
    
            tableRow = $("#tab-ofdm th").filter(function() {
                return $(this).text() == "Frequency (MHz)";
            }).closest('tr');
    
            $(tableRow).find('td').each (function() {
            var count = $(this).text().length;
            total = spacing - count -1;
            texty += $(this).text();  
            for (i=0; i < total; i++){
                    texty += "\xa0";
                }    
            }); 
			
			texty += "\nPower:\xa0";
            tableRow = $("#tab-ofdm th").filter(function() {
                return $(this).text() == "Rx Power (dBmV)";
            }).closest('tr');
    
            $(tableRow).find('td').each (function() {
            var count = $(this).text().length;
            total = spacing - count -1;
            texty += $(this).text();  
            for (i=0; i < total; i++){
                    texty += "\xa0";
                }
            }); 
			
			// Upstream
			texty += "\n\nUpstream\n========\n";
            texty += "Freq:\xa0";
    
            tableRow = $("#tab-us th").filter(function() {
                return $(this).text() == "Frequency (MHz)";
            }).closest('tr');
    
            $(tableRow).find('td').each (function() {

                var choptext = $(this).text();
                var count = choptext.length;
                total = spacing - count;
                texty += choptext;  
                for (i=0; i < total; i++){
                    texty += "\xa0";
                }    
            });  
    
            texty += "\nTX:\xa0\xa0\xa0";
    
            tableRow = $("#tab-us th").filter(function() {
                return $(this).text() == "Tx Power (dBmV)";
            }).closest('tr');
        
            $(tableRow).find('td').each (function() {
        
                var count = $(this).text().length;
                total = spacing - count;
                texty += $(this).text();  
                for (i=0; i < total; i++){
                    texty += "\xa0";
                }
            }); 
			
			texty += "\nSNR:\xa0\xa0";
    
            tableRow = $("#tab-us th").filter(function() {
                return $(this).text() == "SNR";
            }).closest('tr');
    
            $(tableRow).find('td').each (function() {

                var count = $(this).text().length;
                total = spacing - count -1;
                texty += $(this).text();  
                for (i=0; i < total; i++){
                    texty += "\xa0\xa0";
                }    
            }); 
			
			// OFDMA
			texty += "\n\nOFDMA:";
			texty += "\nFreq:\xa0\xa0";
    
            tableRow = $("#tab-ofdma th").filter(function() {
                return $(this).text() == "Frequency (MHz)";
            }).closest('tr');
    
            $(tableRow).find('td').each (function() {
            var count = $(this).text().length;
            total = spacing - count -1;
            texty += $(this).text();  
            for (i=0; i < total; i++){
                    texty += "\xa0";
                }    
            }); 
			
			texty += "\nPower:\xa0";
            tableRow = $("#tab-ofdma th").filter(function() {
                return $(this).text() == "Tx Power (dBmV)";
            }).closest('tr');
    
            $(tableRow).find('td').each (function() {
            var count = $(this).text().length;
            total = spacing - count -1;
            texty += $(this).text();  
            for (i=0; i < total; i++){
                    texty += "\xa0";
                }    
            }); 
			
            texty += "";
            $('h1').append('<span id="copied" class="copied" style="color:red;font-size: 0.8em;">copied</span>');
            $('.copied').fadeOut(1000);

            return texty;
        }
        
    }); 

  
}