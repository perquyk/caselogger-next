// ==UserScript==
// @livenode
// @include http://ants.inet.telenet.be/tools/nodes/newnodeping*
// @include http://ants.inet.telenet.be/tools/nodes/livenodeping*
// @require jquery-1.11.2.js
// @require jquery-ui.js
// ==/UserScript==


$( "body" ).on( "click", "td input", function() {
			if(kango.storage.getItem('option2') !== 1){
			var oke = $(this).closest("td").prevAll(":eq(5)").text();
			oke += ' '+ $(this).closest("td").prevAll(":eq(4)").text();
			var busnr =  " bus " +$(this).closest("td").prevAll(":eq(3)").text();
			if(busnr !== " bus "){
				oke += busnr;
			}
			kango.storage.setItem("straat", oke);
			}
});