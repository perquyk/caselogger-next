﻿function MyExtension() {
    var self = this;
    kango.ui.browserButton.addEventListener(kango.ui.browserButton.event.COMMAND, function() {
        self._onCommand();
    });
}

MyExtension.prototype = {

    _onCommand: function() {
    	kango.ui.optionsPage.open();
        //kango.browser.tabs.create({url: 'http://ants.inet.telenet.be/'});
    }
};

var extension = new MyExtension();