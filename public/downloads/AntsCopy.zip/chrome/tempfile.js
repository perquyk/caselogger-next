kleurWaarde = function(value , type){
    switch(type)
    {
        case 'schommel':

            var style ="";
            if (value >= 6){
                style = 'class="text-state-error"';
            }else{
                style = 'class="text-state-success"';
            }
            return style;

        case 'ussnr':

            if (value >= 34){
            style = 'class="text-state-success"';        
            }else{
                if (value < 30){
                    style = 'class="text-state-error"';
                }else{
                    style ='class="text-state-warning"';
                }        
            }
            return style;

        case 'tx':
            
            var style ="";
            if ((value <= 15) && (value >= -13)){
                
                if(value < -4){
                    style ='class="text-state-warning"';
                    
                    
                }else{
                    style = 'class="text-state-success"';
                }
            }else{
                style = 'class="text-state-error"';
                
            }
            return style;

        case 'rx':

            var style ="";
            if ((value <= 52) && (value >= 26)){
                if((value <= 47) && (value >= 28)){
                    style = 'class="text-state-success"';
                }else{
                    style ='class="text-state-warning"';
                    
                }
                
            }else{
                style = 'class="text-state-error"';
                
            }
            return style;

    }
}

kleurTd = function(value){
    var style ="";
    if (value >= 6){
        style = 'class="text-state-error"';
    }else{
        style = 'class="text-state-success"';
    }
    return style;
}

kleurSnr = function(value){
    var style ="";
    if (value >= 34){
        
        style = 'class="text-state-success"';
        
    }else{
        if (value < 30){
          style = 'class="text-state-error"';
        }else{
          style ='class="text-state-warning"';
        }
        
        
    }
    return style;
}

kleurRx = function(value){
    var style ="";
    if ((value <= 15) && (value >= -13)){
        
        if(value < -4){
            style ='class="text-state-warning"';
            
            
        }else{
            style = 'class="text-state-success"';
        }
    }else{
        style = 'class="text-state-error"';
        
    }
    return style;
}
kleurTx = function(value){
    var style ="";
    if ((value <= 52) && (value >= 26)){
        if((value <= 47) && (value >= 28)){
            style = 'class="text-state-success"';
        }else{
            style ='class="text-state-warning"';
            
        }
        
    }else{
        style = 'class="text-state-error"';
        
    }
    return style;
}


// tx TOEVOEGEN
        var arTX = {};
        var keyPrev = $('#tab-levels #data-table tr').find('td:eq(4):not(:empty):first').eq(0).text();
        $('#tab-levels #data-table tr').each(function(){
            $(this).find('td:eq(5)').each(function(){
                
                if($(this).text() !== ""){
                    if ($(this).prevAll(":eq(0)").text() !== ""){
                        var keyt = $(this).prevAll(":eq(0)").text();
                        keyPrev = keyt;
                    }else{
                        var keyt = keyPrev;
                    }
                    
                    var value = $(this).text();
                    
                    
                    if ( keyt in arTX ){
                        arTX[keyt].push(value);
                    } else { 
                        arTX[keyt] = [value];
                    }
                    
                    
                }
            })
        });
        var txtext = "";
        txtext += '<table class="data-table" cellspacing="0" style="text-align:center;"><thead><tr><th style="min-width:207px;">TX freq</th><th>Minimum</th><th>Maximum</th><th>Schommeling</th>';
        $.each(arTX, function( index) {
            txtext += "<tr>";
            var min = Math.min.apply(Math,arTX[index]);
            var max = Math.max.apply(Math,arTX[index]); // 3
            console.log(max);
            var schommel = parseFloat((max - min).toFixed(1));
            console.log(schommel);
            txtext += "<td>"+ index + "</td><td "+kleurTx(min)+">"+min+"</td><td "+kleurTx(max)+">"+max+"</td><td "+kleurTd(schommel)+">"+ schommel +"</td></tr>" ;

        });
        txtext +="</table>";
        $('#tab-levels').css({"margin-left":"500px"});
        $('#tab-levels').prepend("<div id='samenvatting' style='width:500px; margin-left:-500px; float:left;'>"+txtext+"</div>");

        // RX TOEVOEGEN
        var arRx = {};
        keyPrev = $('#tab-levels #data-table tr').find('td:eq(1):not(:empty):first').eq(0).text();
        $('#tab-levels #data-table tr').each(function(){
            $(this).find('td:eq(2)').each(function(){
                
                if($(this).text() !== ""){
                    if ($(this).prevAll(":eq(0)").text() !== ""){
                        var keyt = $(this).prevAll(":eq(0)").text();
                        keyPrev = keyt;
                    }else{
                        var keyt = keyPrev;
                    }
                    
                    var value = $(this).text();
                    
                    
                    if ( keyt in arRx ){
                        arRx[keyt].push(value);
                    } else { 
                        arRx[keyt] = [value];
                    }
                    
                    
                }
            })
        });
        var rxtext = "";
        rxtext += '<table class="data-table" cellspacing="0" style="text-align:center;"><thead><tr><th style="min-width:207px;">Rx freq</th><th>Minimum</th><th>Maximum</th><th>Schommeling</th>';
        $.each(arRx, function( index) {
            rxtext += "<tr>";
            var min = Math.min.apply(Math,arRx[index]);
            var max = Math.max.apply(Math,arRx[index]); // 3
            console.log(max);
            var schommel = parseFloat((max - min).toFixed(1));
            console.log(schommel);
            rxtext += "<td>"+ index + "</td><td "+kleurRx(min)+">"+min+"</td><td "+kleurRx(max)+">"+max+"</td><td "+kleurTd(schommel)+">"+ schommel +"</td></tr>" ;

        });
        rxtext +="</table>";
        $('#samenvatting').append(rxtext);

        // snr TOEVOEGEN
        var arSNR = {};
        keyPrev = $('#tab-levels #data-table tr').find('td:eq(1):not(:empty):first').eq(0).text();
        $('#tab-levels #data-table tr').each(function(){
            $(this).find('td:eq(3)').each(function(){
                
                if($(this).text() !== ""){
                    if ($(this).prevAll(":eq(1)").text() !== ""){
                        var keyt = $(this).prevAll(":eq(1)").text();
                        keyPrev = keyt;
                    }else{
                        var keyt = keyPrev;
                    }
                    
                    var value = $(this).text();
                    
                    
                    if ( keyt in arSNR ){
                        arSNR[keyt].push(value);
                    } else { 
                        arSNR[keyt] = [value];
                    }
                    
                    
                }
            })
        });
        var snrtext = "";
        snrtext += '<table class="data-table" cellspacing="0" style="text-align:center;"><thead><tr><th style="min-width:207px;">SNR freq</th><th>Minimum</th><th>Maximum</th><th>Schommeling</th>';
        $.each(arSNR, function( index) {
            snrtext += "<tr>";
            var min = Math.min.apply(Math,arSNR[index]);
            var max = Math.max.apply(Math,arSNR[index]); // 3
            console.log(max);
            var schommel = parseFloat((max - min).toFixed(1));
            console.log(schommel);
            snrtext += "<td>"+ index + "</td><td "+kleurSnr(min)+">"+min+"</td><td "+kleurSnr(max)+">"+max+"</td><td "+kleurTd(schommel)+">"+ schommel +"</td></tr>" ;

        });
        snrtext +="</table>";