===================
ANTSCopy Remastered
===================

Installatie: 
1) .zip bestandje uitpakken, en de "chrome" map ergens veilig wegzetten.
2) Daarna surfen via Chrome naar chrome://extensions.
3) "Developer mode" aanzetten, indien deze nog niet aanstond.
4) "Load unpacked" aanklikken en navigeren naar de chrome map die je hebt uitgepakt.
5) De instellingen aanpassen kan je door op het AntsCopy logo te klikken bij de extensies.

Fixes:

Copy button now works again as intended.
Status historiek now shows the eventlog again.
Level historiek shows the level charts again.
Live nodeping module & proper display of busnumbers.

Changes:

Copy button now includes OFDM/OFDMA information, instead of adding it to the back of the single QAM list.
Copy button now includes USSNR information.
Copy button now includes last reboot reason. (newer modems only)
Copy button now includes more WAN IP information.
Status historiek: USSNR chart scale changed to include lower SNR values.
Removed QR code option, as this was outdated, not secure, and wasn't working anymore due to the removal of SmartAid.